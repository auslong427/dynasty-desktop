import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './app.css';

// Create the root element and mount the React application. By separating
// the main entry point from the application logic we make the code
// easier to reason about and enable hot module reloading when running
// locally with Vite.
ReactDOM.createRoot(document.getElementById('root') as HTMLElement).render(
  <React.StrictMode>
    <App />
  </React.StrictMode>
);