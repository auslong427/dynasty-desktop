/*
 * A collection of small analysis helpers used throughout the Dynasty Desktop
 * application. These functions perform CSV parsing, value joins, basic
 * scarcity calculations, Monte Carlo simulation of season wins, and a
 * greedy trade proposal generator. Keeping analytics in a dedicated
 * module isolates complexity from the UI and encourages reuse.
 */

export function parseCSV(text: string): Record<string, string>[] {
  if (!text) return [];
  const lines = text.replace(/^\uFEFF/, '').split(/\r?\n/);
  let head: string[] | null = null;
  const rows: Record<string, string>[] = [];
  for (const line of lines) {
    if (!line.trim()) continue;
    const cells: string[] = [];
    let c = '';
    let q = false;
    for (let i = 0; i < line.length; i++) {
      const ch = line[i];
      if (ch === '"') {
        if (q && line[i + 1] === '"') {
          c += '"';
          i++;
        } else {
          q = !q;
        }
      } else if (ch === ',' && !q) {
        cells.push(c);
        c = '';
      } else {
        c += ch;
      }
    }
    cells.push(c);
    if (!head) {
      head = cells;
      continue;
    }
    const row: Record<string, string> = {};
    head.forEach((h, idx) => {
      row[h] = (cells[idx] ?? '').trim();
    });
    rows.push(row);
  }
  return rows;
}

export type ValueMaps = {
  bySleeper1QB: Map<string, number>;
  bySleeper2QB: Map<string, number>;
};

/**
 * Join dynasty values by Sleeper IDs using DynastyProcess CSVs. This
 * function accepts the raw CSV strings and returns two maps keyed by
 * Sleeper ID containing 1QB and Superflex values respectively.
 */
export function joinValuesByIDs(idsCSV: string, valuesCSV: string): ValueMaps {
  const ids = parseCSV(idsCSV);
  const vals = parseCSV(valuesCSV);
  const idCols = Object.keys(ids[0] || {});
  const sidCol = idCols.find((c) => /sleeper_id/i.test(c)) || 'sleeper_id';
  const fpColI = idCols.find((c) => /(fp_|fantasypros).*id/i.test(c)) || 'fantasypros_id';
  const valCols = Object.keys(vals[0] || {});
  const fpColV = valCols.find((c) => /^fp_id$/i.test(c)) || 'fp_id';
  const v1Col = valCols.find((c) => /value_1qb/i.test(c)) || 'value_1qb';
  const v2Col = valCols.find((c) => /value_2qb/i.test(c)) || 'value_2qb';
  const fpBySleeper = new Map(
    ids.map((r) => [String(r[sidCol] || '').trim(), String(r[fpColI] || '').trim()])
  );
  const valuesMap = new Map(
    vals.map((r) => [
      String(r[fpColV] || '').trim(),
      {
        v1: Number(String(r[v1Col] || '0').replace(/[^0-9.\-]/g, '')),
        v2: Number(String(r[v2Col] || '0').replace(/[^0-9.\-]/g, '')),
      },
    ])
  );
  const bySleeper1QB = new Map<string, number>();
  const bySleeper2QB = new Map<string, number>();
  for (const [sid, fpid] of fpBySleeper.entries()) {
    const v = valuesMap.get(fpid);
    if (!v) continue;
    if (Number.isFinite(v.v1)) bySleeper1QB.set(sid, v.v1);
    if (Number.isFinite(v.v2)) bySleeper2QB.set(sid, v.v2);
  }
  return { bySleeper1QB, bySleeper2QB };
}

/**
 * Compute a basic positional scarcity index from a players directory and
 * a value lookup function. Returns an object keyed by position with
 * median, replacement and scarcity values.
 */
export function scarcityByPosition(
  playersDir: Record<string, any>,
  valueForPid: (pid: string) => number
) {
  const buckets: Record<string, number[]> = {};
  for (const pid of Object.keys(playersDir)) {
    const p = playersDir[pid];
    const pos: string = p?.position || 'UNK';
    const v = valueForPid(pid);
    if (!v) continue;
    (buckets[pos] ||= []).push(v);
  }
  const out: Record<string, { median: number; replacement: number; scarcity: number }> = {};
  for (const [pos, arr] of Object.entries(buckets)) {
    arr.sort((a, b) => b - a);
    const median = arr.length ? arr[Math.floor(arr.length * 0.5)] : 0;
    const replacement = arr.length ? arr[Math.floor(arr.length * 0.67)] : 0; // ~WR3/RB3 tier
    out[pos] = { median, replacement, scarcity: median - replacement };
  }
  return out;
}

/**
 * Monte Carlo simulation of season wins. We assume each team scores from
 * a normal distribution centred on its team value and with standard deviation
 * derived from the league spread. The simulation runs a number of
 * iterations of round‑robin matchups to approximate expected wins.
 */
export function simulateSeasonWins(
  teamValues: number[],
  weeks: number,
  iters = 5000
) {
  const n = teamValues.length;
  const sigma = Math.max(
    50,
    standardDeviation(teamValues)
  );
  const wins = new Array(n).fill(0);
  function rnd() {
    // Box–Muller transform for a normal random variable
    let u = 0;
    let v = 0;
    while (!u) u = Math.random();
    while (!v) v = Math.random();
    return Math.sqrt(-2 * Math.log(u)) * Math.cos(2 * Math.PI * v);
  }
  for (let k = 0; k < iters; k++) {
    const w = new Array(n).fill(0);
    for (let week = 0; week < weeks; week++) {
      for (let a = 0; a < n; a++) {
        for (let b = a + 1; b < n; b++) {
          const sa = teamValues[a] + sigma * rnd();
          const sb = teamValues[b] + sigma * rnd();
          if (sa > sb) w[a]++;
          else w[b]++;
        }
      }
    }
    for (let i = 0; i < n; i++) wins[i] += w[i];
  }
  return wins.map((x) => x / iters);
}

function standardDeviation(arr: number[]): number {
  const n = arr.length;
  if (n === 0) return 0;
  const mean = arr.reduce((sum, v) => sum + v, 0) / n;
  const variance = arr.reduce((sum, v) => sum + (v - mean) ** 2, 0) / n;
  return Math.sqrt(variance);
}

/**
 * Greedy trade proposal generator. Given rosters with positional counts and
 * values, identify potential swaps that address positional shortages while
 * keeping total value close between the trade partners. This function
 * returns a list of proposals sorted by closeness of value (delta).
 */
export function proposeTrades(
  rosters: {
    team: string;
    positions: Record<string, number>;
    value: number;
    players: string[];
  }[],
  shortage: Record<string, string[]>, // team -> needed positions
  valueForName: (name: string) => number,
  maxPackagesPerTeam = 3
) {
  const proposals: {
    from: string;
    to: string;
    give: string[];
    get: string[];
    delta: number;
  }[] = [];
  for (const t of rosters) {
    for (const need of shortage[t.team] || []) {
      const donors = rosters
        .filter((o) => o !== t && (o.positions[need] || 0) > (t.positions[need] || 0) + 1)
        .sort((a, b) => (b.positions[need] - a.positions[need]));
      for (const d of donors.slice(0, 3)) {
        const donorBest = d.players
          .filter((n) => valueForName(n) > 0)
          .sort((a, b) => valueForName(b) - valueForName(a))[0];
        const wantValue = valueForName(donorBest) || 0;
        const give = t.players
          .filter((n) => valueForName(n) > 0)
          .sort((a, b) =>
            Math.abs(valueForName(a) - wantValue) -
            Math.abs(valueForName(b) - wantValue)
          )[0];
        const delta = (valueForName(donorBest) || 0) - (valueForName(give) || 0);
        proposals.push({ from: d.team, to: t.team, give: [donorBest], get: [give], delta });
        if (proposals.length >= maxPackagesPerTeam) break;
      }
    }
  }
  return proposals
    .sort((a, b) => Math.abs(a.delta) - Math.abs(b.delta))
    .slice(0, 20);
}