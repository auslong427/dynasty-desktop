/*
 * Data connectors for Sleeper and DynastyProcess. These functions
 * encapsulate all network access within a single module, making the
 * rest of the application easier to test and reason about. The
 * Tauri HTTP plugin is used at runtime to perform cross‑origin
 * requests from the desktop application; when running in a browser
 * context (e.g. during a web build), the native fetch API can be
 * used instead.
 */

// Conditionally import the Tauri HTTP plugin. When bundled as a
// desktop app the plugin will be available; when running in a web
// environment it will be undefined and we fall back to window.fetch.
let tfetch: any;
try {
  // eslint-disable-next-line @typescript-eslint/no-var-requires
  tfetch = require('@tauri-apps/plugin-http').fetch;
} catch {
  tfetch = undefined;
}

async function httpFetch(url: string, options: any = {}): Promise<any> {
  // Fetch JSON by default. The Tauri plugin returns a Response like object
  // with json(), text(), etc. When running in the browser we call
  // window.fetch and parse JSON.
  if (tfetch) {
    const res = await tfetch(url, options);
    if (res.status >= 400) throw new Error(`${url} -> ${res.status}`);
    return res.json();
  }
  const res = await fetch(url, options);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.json();
}

async function httpFetchText(url: string, options: any = {}): Promise<string> {
  // Fetch plain text (used for CSV files). The Tauri plugin exposes a text() method.
  if (tfetch) {
    const res = await tfetch(url, options);
    if (res.status >= 400) throw new Error(`${url} -> ${res.status}`);
    return res.text();
  }
  const res = await fetch(url, options);
  if (!res.ok) throw new Error(`${url} -> ${res.status}`);
  return res.text();
}

// Sleeper API endpoints (no authentication required)
const SLP = 'https://api.sleeper.app/v1';
export const sleeper = {
  league: (id: string) => httpFetch(`${SLP}/league/${id}`),
  users: (id: string) => httpFetch(`${SLP}/league/${id}/users`),
  rosters: (id: string) => httpFetch(`${SLP}/league/${id}/rosters`),
  transactionsByWeek: (id: string, week: number) => httpFetch(`${SLP}/league/${id}/transactions/${week}`),
  playersDir: () => httpFetch('https://api.sleeper.app/v1/players/nfl'),
};

// DynastyProcess data sources hosted on GitHub / jsDelivr. These are
// publicly available CSV files updated weekly and do not require any
// authentication.
const GH =
  'https://raw.githubusercontent.com/dynastyprocess/data/gh-pages/files';
export const dynastyProcess = {
  playerIdsCSV: () => httpFetchText(`${GH}/db_playerids.csv`, { method: 'GET' }),
  valuesPlayersCSV: () => httpFetchText(`${GH}/values-players.csv`, { method: 'GET' }),
  valuesPicksCSV: () => httpFetchText(`${GH}/values-picks.csv`, { method: 'GET' }),
};