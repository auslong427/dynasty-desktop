#![cfg_attr(not(debug_assertions), windows_subsystem = "windows")]

// The entry point for the Tauri application. This minimal main function
// registers the HTTP plugin and starts the application using the
// context generated from the tauri.conf.json. The HTTP plugin is
// required to enable network requests to Sleeper and DynastyProcess
// endpoints without hitting CORS issues.

fn main() {
    tauri::Builder::default()
        .plugin(tauri_plugin_http::init())
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}