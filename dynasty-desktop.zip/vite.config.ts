import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

// Vite configuration for the Dynasty Desktop project.
// This file sets up the React plugin and leaves the rest of the defaults intact.
// The build output will end up in the `dist` directory, which is referenced by
// the Tauri configuration.

export default defineConfig({
  plugins: [react()],
});